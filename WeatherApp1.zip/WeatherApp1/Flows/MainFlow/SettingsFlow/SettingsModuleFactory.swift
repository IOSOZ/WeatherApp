//
//  SettingsModuleFactory.swift
//  WeatherApp
//
//  Created by Олег Зуев on 07.05.2026.
//

import Foundation
import UIKit

final class SettingsModuleFactory {
    func makeSettingsViewController(
        onMainFlow: @escaping () -> Void
    ) -> UIViewController {
        let viewModel = SettingsViewModel()
        
        viewModel.onMainFlow = onMainFlow
        
        let viewController = SettingsViewController(viewModel: viewModel)
        return viewController
    }
}
