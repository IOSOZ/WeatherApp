//
//  SettingsViewModel.swift
//  WeatherApp
//
//  Created by Олег Зуев on 07.05.2026.
//

import Foundation

protocol SettingsViewModelInput {
    func didTapBackOnMainFlow()
}

final class SettingsViewModel: SettingsViewModelInput {
    // MARK: - Outputs
    var onMainFlow: (() -> Void)?
    
    // MARK: - Setup Logic
    func didTapBackOnMainFlow() {
        onMainFlow?()
    }
}
