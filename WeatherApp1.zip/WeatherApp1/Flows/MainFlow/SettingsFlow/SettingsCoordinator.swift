//
//  GreenScreenCoordinator.swift
//  WeatherApp
//
//  Created by Олег Зуев on 07.05.2026.
//

import Foundation
import UIKit

protocol SettingsCoordinatorFactory {
    func makeSettingsCoordinator()
}

final class SettingsCoordinator: Coordinator {
    
    // MARK: - Flow Work
    var childCoordinators: [any Coordinator]
    
    var onFinish: (() -> Void)?
    
    private let factory: SettingsCoordinatorFactory
    private let moduleFactory = SettingsModuleFactory()
    
    // MARK: - NavController
    let navController = UINavigationController()
    
    init (factory: SettingsCoordinatorFactory) {
        self.factory = factory
    }
    
    func start() {
        <#code#>
    }
}

private extension SettingsCoordinator {
    func showSettingsScreen() {
        let vc = moduleFactory.makeSettingsViewController {
            factory.
        }
    }
}
